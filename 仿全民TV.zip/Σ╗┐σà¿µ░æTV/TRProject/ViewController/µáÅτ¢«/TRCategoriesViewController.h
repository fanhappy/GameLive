//
//  TRCategoriesViewController.h
//  TRProject
//
//  Created by fanzhilin on 16/3/8.
//  Copyright © 2016年 fanzhilin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRBaseViewController.h"

@interface TRCategoriesViewController : TRBaseViewController

@end
