//
//  TRCategoriesModel.m
//  TRProject
//
//  Created by fanzhilin on 16/3/7.
//  Copyright © 2016年 fanzhilin. All rights reserved.
//

#import "TRCategoriesModel.h"

@implementation TRCategoriesModel

@end

