//
//  TRCategoryModel.m
//  TRProject
//
//  Created by fanzhilin on 16/3/7.
//  Copyright © 2016年 fanzhilin. All rights reserved.
//

#import "TRCategoryModel.h"

@implementation TRCategoryModel

+ (NSDictionary *)objClassInArray{
    return @{@"data" : [TRCategoryDataModel class]};
}
@end

@implementation TRCategoryDataModel

@end


