//
//  AppDelegate.h
//  TRProject
//
//  Created by fanzhilin on 16/2/4.
//  Copyright © 2016年 fanzhilin. All rights reserved.
//


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic) UITabBarController *tabC;
@end

