//
//  EditNicknameViewController.h
//  ChatDemo-UI2.0
//
//  Created by EaseMob on 15/4/16.
//  Copyright (c) 2015年 EaseMob. All rights reserved.
//

#import "BaseViewController.h"

@interface EditNicknameViewController : BaseViewController

@end
