//
//  EMRotbotChatViewCell.m
//  ChatDemo-UI2.0
//
//  Created by dujiepeng on 15/8/3.
//  Copyright (c) 2015年 dujiepeng. All rights reserved.
//

#import "EMRotbotChatViewCell.h"
#import "EMRobotChatTextBubbleView.h"

@implementation EMRotbotChatViewCell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
