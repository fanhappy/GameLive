//
//  EMRobotChatTextBubbleView.h
//  ChatDemo-UI2.0
//
//  Created by dujiepeng on 15/8/3.
//  Copyright (c) 2015年 dujiepeng. All rights reserved.
//

//#import "EMChatTextBubbleView.h"

@interface EMRobotChatTextBubbleView : NSObject

@end
