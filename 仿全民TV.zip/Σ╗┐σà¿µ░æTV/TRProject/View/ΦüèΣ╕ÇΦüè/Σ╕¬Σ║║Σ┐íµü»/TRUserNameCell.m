//
//  TRUserNameCell.m
//  TRProject
//
//  Created by fanzhilin on 16/3/11.
//  Copyright © 2016年 fanzhilin. All rights reserved.
//

#import "TRUserNameCell.h"

@implementation TRUserNameCell

- (void)awakeFromNib {
    // Initialization code
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseIdentifier]) {
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
