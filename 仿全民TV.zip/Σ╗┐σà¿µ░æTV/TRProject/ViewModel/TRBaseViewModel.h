//
//  TRBaseViewModel.h
//  TRProject
//
//  Created by fanzhilin on 16/3/7.
//  Copyright © 2016年 fanzhilin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+ViewModel.h"
@interface TRBaseViewModel : NSObject

@end
